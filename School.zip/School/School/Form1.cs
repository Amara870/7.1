namespace School
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            cmbOccupation.Items.Clear();
            cmbOccupation.Items.Add("Teacher");
            cmbOccupation.Items.Add("Student");
            btnFinish.Enabled = false;
            cmbOccupation.Enabled = false;
            txtName.ReadOnly = true;
            txtSchool.ReadOnly = true;
        }



        private void Form1_Load_2(object sender, EventArgs e)
        {

        }

        private void btnStart_Click(object sender, EventArgs e)
        {

            btnFinish.Enabled = true;
            cmbOccupation.Enabled = true;
            txtName.ReadOnly = false;
            txtSchool.ReadOnly = false;
        }

        private void CheckInput()
        {
            string txt1 = txtName.Text;
            string txt2 = txtSchool.Text;
            string cmb1 = cmbOccupation.Text;
            if (String.IsNullOrWhiteSpace(txt1) || String.IsNullOrWhiteSpace(txt2) || String.IsNullOrWhiteSpace(cmb1))
            {
                MessageBox.Show("Please fill out all inquiries on the form!");
            }
            else
            {
                MessageBox.Show("Thank you for submitting your application!");
                cmbOccupation.Enabled = false;
                txtName.ReadOnly = true;
                txtSchool.ReadOnly = true;

            }
        }

        private void btnFinish_Click_1(object sender, EventArgs e)
        {

            CheckInput();

        }

        private void CheckIfLetter()
        {
            if (!System.Text.RegularExpressions.Regex.IsMatch(txtSchool.Text, "^[a-z A-Z]*$"))
            {
                MessageBox.Show("Please enter only letters.");
                txtSchool.Text = " ";
            }
            else
            {

            }
        }
        private void txtSchool_TextChanged(object sender, EventArgs e)
        {
            CheckIfLetter();
        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(txtName.Text, "^[0-9 ]*$"))
            {
                MessageBox.Show("Please enter only letters.");
                txtName.Text = " ";
            }
        }

    }
}