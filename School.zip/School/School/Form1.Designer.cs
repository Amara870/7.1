﻿namespace School
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnStart = new Button();
            btnFinish = new Button();
            lblName = new Label();
            lblOccupation = new Label();
            lblSchool = new Label();
            txtName = new TextBox();
            txtSchool = new TextBox();
            cmbOccupation = new ComboBox();
            SuspendLayout();
            // 
            // btnStart
            // 
            btnStart.Location = new Point(344, 265);
            btnStart.Name = "btnStart";
            btnStart.Size = new Size(112, 34);
            btnStart.TabIndex = 0;
            btnStart.Text = "Start";
            btnStart.UseVisualStyleBackColor = true;
            btnStart.Click += btnStart_Click;
            // 
            // btnFinish
            // 
            btnFinish.Location = new Point(346, 329);
            btnFinish.Name = "btnFinish";
            btnFinish.Size = new Size(112, 34);
            btnFinish.TabIndex = 1;
            btnFinish.Text = "Finish";
            btnFinish.UseVisualStyleBackColor = true;
            btnFinish.Click += btnFinish_Click_1;
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Location = new Point(204, 72);
            lblName.Name = "lblName";
            lblName.Size = new Size(59, 25);
            lblName.TabIndex = 2;
            lblName.Text = "Name";
            // 
            // lblOccupation
            // 
            lblOccupation.AutoSize = true;
            lblOccupation.Location = new Point(160, 125);
            lblOccupation.Name = "lblOccupation";
            lblOccupation.Size = new Size(103, 25);
            lblOccupation.TabIndex = 3;
            lblOccupation.Text = "Occupation";
            // 
            // lblSchool
            // 
            lblSchool.AutoSize = true;
            lblSchool.Location = new Point(204, 182);
            lblSchool.Name = "lblSchool";
            lblSchool.Size = new Size(66, 25);
            lblSchool.TabIndex = 4;
            lblSchool.Text = "School";
            // 
            // txtName
            // 
            txtName.Location = new Point(306, 72);
            txtName.Name = "txtName";
            txtName.Size = new Size(150, 31);
            txtName.TabIndex = 5;
            txtName.TextChanged += txtName_TextChanged;
            // 
            // txtSchool
            // 
            txtSchool.Location = new Point(306, 176);
            txtSchool.Name = "txtSchool";
            txtSchool.Size = new Size(150, 31);
            txtSchool.TabIndex = 7;
            txtSchool.TextChanged += txtSchool_TextChanged;
            // 
            // cmbOccupation
            // 
            cmbOccupation.FormattingEnabled = true;
            cmbOccupation.Location = new Point(306, 125);
            cmbOccupation.Name = "cmbOccupation";
            cmbOccupation.Size = new Size(182, 33);
            cmbOccupation.TabIndex = 8;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(cmbOccupation);
            Controls.Add(txtSchool);
            Controls.Add(txtName);
            Controls.Add(lblSchool);
            Controls.Add(lblOccupation);
            Controls.Add(lblName);
            Controls.Add(btnFinish);
            Controls.Add(btnStart);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load_2;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnStart;
        private Button btnFinish;
        private Label lblName;
        private Label lblOccupation;
        private Label lblSchool;
        private TextBox txtName;
        private TextBox txtSchool;
        private ComboBox cmbOccupation;
    }
}